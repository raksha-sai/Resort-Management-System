# CSE-311-Database
Resort Management system which was a project of cse 311


## Getting Started

The submitted data will be stored according to the schema, inside a mysql database.

### Prerequisites



### Installing


## Running the tests




## Deployment



## Built With




## Acknowledgments



## License


